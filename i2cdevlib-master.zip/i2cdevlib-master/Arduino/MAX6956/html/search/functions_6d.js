var searchData=
[
  ['max6956',['MAX6956',['../classMAX6956.html#a210d9e95978d61357db757cb80475bde',1,'MAX6956::MAX6956()'],['../classMAX6956.html#a1a7b33190871a09d81c5bec741b645b7',1,'MAX6956::MAX6956(uint8_t address)']]]
];
