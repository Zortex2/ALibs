var searchData=
[
  ['getconfigreg',['getConfigReg',['../classMAX6956.html#a5e787204b3f7bf8750376f5bdf77a971',1,'MAX6956']]],
  ['getenableindividualcurrent',['getEnableIndividualCurrent',['../classMAX6956.html#abcfe81dd0ffc90284f19503b6366dcfb',1,'MAX6956']]],
  ['getenabletransitiondetection',['getEnableTransitionDetection',['../classMAX6956.html#a76e9ab35769854b3e4224499897601ec',1,'MAX6956']]],
  ['getglobalcurrent',['getGlobalCurrent',['../classMAX6956.html#a1926760b263588314fd759d129091940',1,'MAX6956']]],
  ['getinputmask',['getInputMask',['../classMAX6956.html#a56245915d7d4cd8fd34629bd91695147',1,'MAX6956']]],
  ['getpower',['getPower',['../classMAX6956.html#acdc18c36735d8015651d4e3c75da4300',1,'MAX6956']]],
  ['gettestmode',['getTestMode',['../classMAX6956.html#ad4f99f08d1cf08c5a0097215e680a80a',1,'MAX6956']]]
];
