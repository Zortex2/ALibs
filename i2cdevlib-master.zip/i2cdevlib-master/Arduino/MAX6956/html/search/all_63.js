var searchData=
[
  ['configallports',['configAllPorts',['../classMAX6956.html#a9e9f11c46bdc86d8e882ed8bb5efabdf',1,'MAX6956']]],
  ['configport',['configPort',['../classMAX6956.html#a5e05bead41c585c68de79bbfed971d19',1,'MAX6956']]],
  ['configports',['configPorts',['../classMAX6956.html#a400393e30fbe196aef43d8edea890228',1,'MAX6956']]]
];
