var searchData=
[
  ['testconnection',['testConnection',['../classMAX6956.html#a60bd352328d77e59a4d51a3c55d38a25',1,'MAX6956']]],
  ['togglepower',['togglePower',['../classMAX6956.html#a993f35d31d1f2489f9d2965c3886f848',1,'MAX6956']]]
];
