var searchData=
[
  ['devaddr',['devAddr',['../classMAX6956.html#a6ba2f8011914df50d6022ab54b27748d',1,'MAX6956']]],
  ['disableallports',['disableAllPorts',['../classMAX6956.html#a93a81ff86316f63ee1ada3529da2a95b',1,'MAX6956']]]
];
