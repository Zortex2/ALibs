var searchData=
[
  ['initialize',['initialize',['../classMAX6956.html#ad63e927adc2427b4b661f2422ddd40d8',1,'MAX6956']]]
];
