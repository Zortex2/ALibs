var searchData=
[
  ['buffer',['buffer',['../classMAX6956.html#a9f4597436b10ee86a02c96c2b0605851',1,'MAX6956']]]
];
